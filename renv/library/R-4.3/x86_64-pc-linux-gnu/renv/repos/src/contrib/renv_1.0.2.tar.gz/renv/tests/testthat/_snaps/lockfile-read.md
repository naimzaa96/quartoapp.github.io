# renv_lockfile_read gives informative error

    Code
      renv_lockfile_read(file)
    Error <simpleError>
      Failed to parse 'renv.lock':
      parse error: premature EOF
                                             {
                           (right here) ------^

