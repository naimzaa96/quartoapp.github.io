# renv_dots_check only sets bioconductor from bioc is not already set

    Code
      f(bioconductor = FALSE, bioc = TRUE)
    Error <simpleError>
      unused argument (bioc = TRUE)

